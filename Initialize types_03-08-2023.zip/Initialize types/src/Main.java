public class Main {
    public static void main(String[] args) {
        char MyLitter = 'G';
        int MyNum = 89;
        byte MyByte =4;
        short MyShort = 56;
        float MyFloat = 4.7333436F;
        double MyDouble = 4.355453532;
        long MyLong = 12121L;


        int i = 546;
        System.out.print(i + " -> ");
        System.out.print(i / 100 + ", ");
        System.out.print(i / 10 % 10 + ", ");
        System.out.print(i % 10 + ".");
    }
}